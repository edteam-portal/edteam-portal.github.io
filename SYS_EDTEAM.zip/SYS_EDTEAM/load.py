import os
import time
import math
import json
import platform
import threading
import tkinter as tk
from datetime import datetime, timezone
import requests
from config import config

try:
    import config
except ImportError:
    config = None

plugin_name = "SYS.EDTEAM"
plugin_version = "1.0.1"

# ==========================================
# CONFIGURATION SUPABASE
# ==========================================
SUPABASE_URL = "https://oailvdigfdoyfcydmabb.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9haWx2ZGlnZmRveWZjeWRtYWJiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQ2MjQzNTAsImV4cCI6MjEwMDIwMDM1MH0.rWEATcSWDyyyeKXWAkCySCZPwTsIFgDRJ7KB1u4OE00"

status_label = None
systeme_actuel = "SYSTÈME INCONNU"
scan_en_cours = False
dernier_solde_fc = None
inventaire_fc_local = None
inventaire_lock = threading.Lock()

def trouver_journal_dir():
    if config and hasattr(config, 'get'):
        jdir = config.get('journaldir')
        if jdir: return jdir
    if platform.system() == 'Windows':
        return os.path.join(os.environ.get('USERPROFILE', ''), 'Saved Games', 'Frontier Developments', 'Elite Dangerous')
    return None

def lire_cle():
    try:
        if os.path.exists(os.path.join(os.path.dirname(os.path.abspath(__file__)), "edteam_key.txt")):
            with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "edteam_key.txt"), 'r') as f:
                return f.read().strip()
    except: pass
    return ""

def sauvegarder_cle(cle):
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "edteam_key.txt"), 'w') as f:
            f.write(cle.strip())
    except: pass

def get_headers():
    cle = lire_cle()
    return {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "x-commandant-key": cle if cle else "NO_KEY",
        "User-Agent": f"SYS.EDTEAM/{cle}" if cle else "SYS.EDTEAM/NO_KEY"
    }

# ==========================================
# LE NOUVEAU PONT DE COMMUNICATION
# ==========================================
def patch_parametres(payload):
    # Utilise radar_commercial comme pont pour passer les infos à l'interface Web
    try:
        data = {"system_name": "SYS_CORE", "station_name": json.dumps(payload), "target_commodity": "PARAM_UPDATE", "type_operation": "STATUS", "prix_unitaire": 0, "volume_disponible": 0, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": 0}
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.PARAM_UPDATE", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{res.json()[0]['id']}", headers=get_headers(), json={"station_name": data["station_name"]})
        else:
            requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=data)
    except: pass

def obtenir_parametres():
    # Lit les paramètres déposés par l'interface Web sur le pont
    try:
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.APP_PARAMS", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            return json.loads(res.json()[0].get('station_name', '{}'))
    except: pass
    return {"cibles_achat": ["Gold"], "moyennes_galactiques": {}, "mode_flotte": "FC"}

def recuperer_dernier_systeme_connu():
    global systeme_actuel
    # Si on connait le système et que ce n'est pas l'erreur de base ni le parachute Sol
    if systeme_actuel != "SYSTÈME INCONNU" and systeme_actuel != "Sol":
        return systeme_actuel
        
    try:
        # Plan A : Lire le dernier statut connu
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.SYSTEM_STATUS", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            sys_db = res.json()[0].get('system_name', '')
            # On bloque Sol pour éviter la boucle
            if sys_db and sys_db not in ["SYSTÈME INCONNU", "SYS_CORE", "SHIP", "FINANCE", "Sol"]:
                systeme_actuel = sys_db
                return systeme_actuel
    except: pass

    try:
        # Plan B : Lire le système de la dernière station trouvée par le radar
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=in.(ACHAT,VENTE,PREDICTIF)&limit=1", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            sys_db = res.json()[0].get('system_name', '')
            if sys_db and sys_db not in ["SYSTÈME INCONNU", "SYS_CORE", "SHIP", "FINANCE", "Sol"]:
                systeme_actuel = sys_db
                return systeme_actuel
    except: pass
    
    try:
        # Plan C : Regarder la dernière transaction du Registre
        res = requests.get(f"{SUPABASE_URL}/rest/v1/journal_transactions?order=created_at.desc&limit=1", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            sys_db = res.json()[0].get('systeme', '')
            if sys_db and sys_db != "INCONNU":
                systeme_actuel = sys_db
                return systeme_actuel
    except: pass
    
    # Plan D (Failsafe absolu) : On crashe sur Sol, mais on ne l'enregistre pas comme vérité
    return "Sol"

# ==========================================
# LE RESTE DES FONCTIONS STANDARDS
# ==========================================
def surveiller_marche_en_fond():
    global systeme_actuel
    jdir = trouver_journal_dir()
    if not jdir: return
    dernier_mtime = 0
    market_path = os.path.join(jdir, 'Market.json')
    status_path = os.path.join(jdir, 'Status.json')
    
    while True:
        try:
            if os.path.exists(status_path):
                with open(status_path, 'r', encoding='utf-8') as f:
                    s_data = json.load(f)
                    if 'SystemName' in s_data: systeme_actuel = s_data['SystemName']

            if os.path.exists(market_path):
                mtime = os.path.getmtime(market_path)
                if mtime != dernier_mtime:
                    dernier_mtime = mtime
                    analyser_marche_detecte(market_path, systeme_actuel)
        except: pass
        time.sleep(1)

def analyser_marche_detecte(market_file, sys_actuel):
    try:
        mettre_a_jour_interface(">_ ANALYSE LOCALE EN COURS...", "#FFD700")
        time.sleep(0.3)
        with open(market_file, 'r', encoding='utf-8') as f: market_data = json.load(f)
        items = market_data.get('Items') or []
        sta_exacte = market_data.get('StationName', "STATION INCONNUE")
        sys_exact = market_data.get('StarSystem', sys_actuel)
        parametres = obtenir_parametres()
        moyennes_gal = parametres.get('moyennes_galactiques', {}) if parametres else {}
        payload_local = []

        for item in sorted(items, key=lambda x: x.get('Stock', 0), reverse=True)[:15]:
            nom_brut = item.get('Name', '') or ''
            if not nom_brut: continue
            nom_marchandise = formater_nom_marchandise(nom_brut)
            stock_reel = item.get('Stock', 0)
            if stock_reel > 0:
                payload_local.append({"system_name": sys_exact, "station_name": sta_exacte, "target_commodity": nom_marchandise, "type_operation": "PREDICTIF_LOCAL", "prix_unitaire": item.get('BuyPrice', 0), "volume_disponible": stock_reel, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": moyennes_gal.get(nom_marchandise, 0)})

        if payload_local:
            sta_safe = sta_exacte.replace(' ', '%20')
            requests.delete(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.PREDICTIF_LOCAL&station_name=eq.{sta_safe}", headers=get_headers())
            requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=payload_local)
            mettre_a_jour_interface(f">_ RAPPORT TRANSMIS : {sta_exacte}", "#00FF66")
        else:
            mettre_a_jour_interface(">_ MARCHE VIDE", "red")
    except:
        mettre_a_jour_interface(">_ ERREUR ANALYSE", "red")

def plugin_start3(plugin_dir):
    threading.Thread(target=ecoute_commandes_distantes, daemon=True).start()
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    threading.Thread(target=surveiller_marche_en_fond, daemon=True).start()
    return plugin_name

def plugin_app(parent):
    global status_label
    frame = tk.Frame(parent)
    tk.Label(frame, text="Compagnon FC - V25", font=("Helvetica", 10, "bold"), fg="#00FF00").grid(row=0, column=0, sticky=tk.W, pady=(5, 0))
    status_label = tk.Label(frame, text="En attente des senseurs...", fg="gray")
    status_label.grid(row=1, column=0, sticky=tk.W)
    return frame

import myNotebook as nb
def plugin_prefs(parent, cmdr, is_beta):
    frame = nb.Frame(parent)
    cle_api_var = tk.StringVar(value=lire_cle())
    tk.Label(frame, text="SYS.EDTEAM - Télémétrie Sécurisée", font=("Helvetica", 10, "bold"), fg="#FF7100").grid(column=0, row=0, columnspan=2, sticky=tk.W, pady=5)
    tk.Label(frame, text="Clé d'Accès :").grid(column=0, row=1, sticky=tk.W)
    entry = tk.Entry(frame, textvariable=cle_api_var, width=45)
    entry.grid(column=1, row=1, sticky=tk.W, padx=10)
    cle_api_var.trace_add("write", lambda *args: sauvegarder_cle(cle_api_var.get()))
    return frame

def mettre_a_jour_interface(texte, couleur):
    global status_label
    if status_label:
        try: status_label.after(0, lambda t=texte, c=couleur: status_label.config(text=t, fg=c))
        except: pass
        
    sys_a_sauver = recuperer_dernier_systeme_connu()
    
    threading.Thread(target=lambda: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json={"system_name": sys_a_sauver, "station_name": texte, "target_commodity": "SYSTEM_STATUS", "type_operation": "INFO", "prix_unitaire": 0, "volume_disponible": 0, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": 0}) if not requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.SYSTEM_STATUS", headers=get_headers()).json() else requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{requests.get(f'{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.SYSTEM_STATUS', headers=get_headers()).json()[0]['id']}", headers=get_headers(), json={"station_name": texte, "system_name": sys_a_sauver})).start()

def maj_cmdr(nom):
    try:
        payload = {"system_name": "SYS_CORE", "station_name": nom, "target_commodity": "CMDR_NAME", "type_operation": "STATUS", "prix_unitaire": 0, "volume_disponible": 0, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": 0}
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.CMDR_NAME", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0: requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{res.json()[0]['id']}", headers=get_headers(), json=payload)
        else: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=payload)
    except: pass

def maj_position_actuelle(systeme):
    """Transmet la position en direct à la base de données pour le PADD mobile"""
    try:
        # Récupération du profil (comme pour les transactions)
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.APP_PARAMS", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            user_id = res.json()[0].get('user_id')
            if user_id:
                # Envoi direct dans la nouvelle colonne
                requests.patch(f"{SUPABASE_URL}/rest/v1/parametres_app?user_id=eq.{user_id}", headers=get_headers(), json={"position_actuelle": systeme})
    except Exception as e:
        print(f"[SYS.EDTEAM] ERREUR BALISE GPS : {e}")

def journal_entry(cmdr, is_beta, system, station, entry, state):
    global systeme_actuel
    if system and system != systeme_actuel: systeme_actuel = system
    event = entry.get('event')
    
    if event in ['FSDJump', 'Location', 'CarrierJump']:
        # -- NOUVEAU : Transmission GPS pour le Mobile --
        threading.Thread(target=maj_position_actuelle, args=(systeme_actuel,)).start()
        
        pos = entry.get('StarPos') 
        if pos and len(pos) == 3:
            mettre_a_jour_interface(f"Recalcul des distances depuis {systeme_actuel}...", "#00F0FF")
            threading.Thread(target=recalcul_distances_mathematiques, args=(pos,)).start()

    elif event == 'LoadGame':
        ship_name = entry.get('ShipName', 'VAISSEAU TACTIQUE')
        possede_fc = entry.get('FleetCarrierID') is not None
        threading.Thread(target=patch_parametres, args=({"vaisseau_nom": ship_name.upper(), "possede_fc": possede_fc},)).start()
        # Envoi du nom du pilote
        threading.Thread(target=maj_cmdr, args=(cmdr,)).start()

    elif event == 'Loadout':
        ship_name = entry.get('ShipName', 'VAISSEAU TACTIQUE')
        cargo_cap = entry.get('CargoCapacity', 0)
        threading.Thread(target=patch_parametres, args=({"vaisseau_nom": ship_name.upper(), "vaisseau_capacite": cargo_cap},)).start()

    elif event == 'CargoTransfer':
        threading.Thread(target=traiter_transfert_soute, args=(entry,)).start()
        
    elif event == 'CarrierStats':
        callsign = entry.get('Callsign', 'XXXX')
        name = entry.get('Name', 'CARRIER INCONNU')
        space = entry.get('SpaceUsage', {})
        cap = space.get('FreeSpace', 25000) + space.get('Cargo', 0)
        threading.Thread(target=patch_parametres, args=({"fc_nom": f"[{callsign}] {name}", "fc_capacite": cap if cap > 0 else 25000, "possede_fc": True},)).start()
        threading.Thread(target=traiter_inventaire_global_fc, args=(entry,)).start()
        
    elif event == 'Cargo':
        threading.Thread(target=traiter_inventaire_vaisseau, args=(entry,)).start()

    elif event == 'MarketBuy':
        threading.Thread(target=enregistrer_transaction, args=(system, station, entry, "ACHAT")).start()
        
    elif event == 'MarketSell':
        threading.Thread(target=enregistrer_transaction, args=(system, station, entry, "VENTE")).start()

def formater_nom_marchandise(nom_brut):
    return {"gold": "Gold", "silver": "Silver", "palladium": "Palladium", "bauxite": "Bauxite", "agronomictreatment": "Agronomic Treatment"}.get(nom_brut.lower(), nom_brut.lower().replace("$", "").replace("_name;", "").title())

def traiter_inventaire_vaisseau(entry):
    if entry.get('Vessel') == 'SRV': return
    try:
        requests.delete(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.SHIP_CARGO", headers=get_headers())
        for item in entry.get('Inventory', []):
            qte = item.get('Count', 0)
            if qte > 0: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json={"system_name": "SHIP", "station_name": "SHIP", "target_commodity": formater_nom_marchandise(item.get('Name', '')), "type_operation": "SHIP_CARGO", "volume_disponible": qte, "prix_unitaire": 0, "distance": 0, "x":0, "y":0, "z":0, "prix_moyen":0})
    except: pass

def traiter_transfert_soute(entry):
    for t in entry.get('Transfers', []):
        changement = t.get('Count', 0) if t.get('Direction') == 'tocarrier' else -t.get('Count', 0)
        maj_bdd_inventaire(formater_nom_marchandise(t.get('Type', '')), changement, relatif=True)

def traiter_inventaire_global_fc(entry):
    global dernier_solde_fc, inventaire_fc_local
    fc_balance = entry.get('Finance', {}).get('CarrierBalance')
    if fc_balance is not None and fc_balance != dernier_solde_fc:
        dernier_solde_fc = fc_balance
        threading.Thread(target=maj_finance, args=("FC_BALANCE", fc_balance)).start()
    
    # Lorsqu'on ouvre l'écran du FC dans le jeu, on force une remise à zéro du cache
    with inventaire_lock:
        inventaire_fc_local = {} 
        
    for c in entry.get('Cargo', []):
        maj_bdd_inventaire(formater_nom_marchandise(c.get('Commodity', '')), c.get('Quantity', 0), relatif=False)

def maj_bdd_inventaire(marchandise, quantite, relatif=True):
    global inventaire_fc_local
    try:
        # 1. On active le sas de sécurité anti-collision
        with inventaire_lock:
            # 2. Chargement du cache local s'il est vide
            if inventaire_fc_local is None:
                inventaire_fc_local = {}
                res = requests.get(f"{SUPABASE_URL}/rest/v1/inventaire_fc", headers=get_headers())
                if res.status_code == 200:
                    for item in res.json():
                        inventaire_fc_local[item.get('marchandise')] = item.get('quantite', 0)

            nouvelle_qte = quantite
            if relatif:
                qte_actuelle = inventaire_fc_local.get(marchandise, 0)
                nouvelle_qte = max(0, qte_actuelle + quantite)
            
            # Mise à jour de la mémoire locale
            inventaire_fc_local[marchandise] = nouvelle_qte

        # 3. Action sur la base de données (hors du verrou)
        # On utilise 'params=' pour que la librairie 'requests' gère parfaitement les espaces (URL Encoding)
        if nouvelle_qte <= 0: 
            requests.delete(
                f"{SUPABASE_URL}/rest/v1/inventaire_fc", 
                headers=get_headers(),
                params={"marchandise": f"eq.{marchandise}"}
            )
        else:
            h = get_headers()
            h["Prefer"] = "resolution=merge-duplicates"
            requests.post(
                f"{SUPABASE_URL}/rest/v1/inventaire_fc", 
                headers=h, 
                params={"on_conflict": "marchandise"},
                json={
                    "marchandise": marchandise, 
                    "quantite": nouvelle_qte, 
                    "derniere_maj": datetime.now(timezone.utc).isoformat()
                }
            )
    except Exception as e: 
        # On retire le 'pass' silencieux pour enfin voir les erreurs si elles existent !
        print(f"[SYS.EDTEAM] ERREUR INVENTAIRE : {e}")

def maj_finance(cible, montant):
    try:
        payload = {"system_name": "FINANCE", "station_name": "BANK", "target_commodity": cible, "type_operation": "FINANCE", "prix_unitaire": montant, "volume_disponible": 0, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": 0}
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.{cible}", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0: requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{res.json()[0]['id']}", headers=get_headers(), json=payload)
        else: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=payload)
    except: pass

def heartbeat_loop():
    while True:
        try:
            timestamp = str(int(time.time()))
            payload = {"system_name": "SYS_CORE", "station_name": timestamp, "target_commodity": "HEARTBEAT", "type_operation": "STATUS", "prix_unitaire": 0, "volume_disponible": 0, "distance": 0, "x": 0, "y": 0, "z": 0, "prix_moyen": 0}
            res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.HEARTBEAT", headers=get_headers())
            if res.status_code == 200 and len(res.json()) > 0: requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{res.json()[0]['id']}", headers=get_headers(), json=payload)
            else: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=payload)
            jdir = trouver_journal_dir()
            if jdir and os.path.exists(os.path.join(jdir, 'Status.json')):
                with open(os.path.join(jdir, 'Status.json'), 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    if data.get('Balance') is not None: maj_finance("SHIP_BALANCE", data.get('Balance'))
        except: pass
        time.sleep(10)

def ecoute_commandes_distantes():
    global scan_en_cours
    while True:
        try:
            res = requests.get(f"{SUPABASE_URL}/rest/v1/commandes_terminal?statut=eq.EN_ATTENTE", headers=get_headers())
            if res.status_code == 200:
                for cmd in res.json():
                    requests.patch(f"{SUPABASE_URL}/rest/v1/commandes_terminal?id=eq.{cmd['id']}", headers=get_headers(), json={"statut": "TRAITEE"})
                    if scan_en_cours: continue
                    action = cmd.get('type_commande')
                    if action == 'SCAN_ACHAT': threading.Thread(target=processus_scan_achats).start()
                    elif action == 'SCAN_VENTE': threading.Thread(target=processus_scan_ventes).start()
                    elif action == 'SCAN_PREDICTIF': threading.Thread(target=processus_scan_predictif).start()
        except: pass
        time.sleep(4)

def processus_scan_achats():
    global scan_en_cours, systeme_actuel
    scan_en_cours = True
    mettre_a_jour_interface("Amorçage des senseurs...", "orange")
    try:
        requests.delete(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.ACHAT", headers=get_headers())
        parametres = obtenir_parametres()
        cibles_vip = [c for c in parametres.get('cibles_achat', []) if c.strip() and "AUCUNE" not in c.upper()]
        moyennes_gal = parametres.get('moyennes_galactiques', {})
        if not cibles_vip:
            mettre_a_jour_interface("Scan annulé : Aucune cible.", "red"); time.sleep(3); mettre_a_jour_interface(f">_ POSITION ACTUELLE : {systeme_actuel.upper()}", "#00F0FF"); scan_en_cours = False; return
        cibles_finales = []
        for i, marchandise in enumerate(cibles_vip):
            achats_temporaires = []
            for (min_dist, max_dist) in [(0, 200), (200, 400), (400, 600), (600, 800), (800, 1000), (1000, 1200)]:
                mettre_a_jour_interface(f"Scan ACHAT [{i+1}/{len(cibles_vip)}] {marchandise} : {min_dist}-{max_dist} AL", "orange")
                for page in range(0, 10):
                    try:
                        res = requests.post("https://spansh.co.uk/api/stations/search", json={"filters": {"commodities": {"value": [marchandise]}, "distance": {"min": min_dist, "max": max_dist}, "has_market": {"value": True}, "is_fleet_carrier": {"value": False}, "has_large_pad": {"value": True}}, "reference_system": recuperer_dernier_systeme_connu(), "size": 250, "page": page}, timeout=10)
                        time.sleep(0.2) 
                        if res.status_code != 200: break 
                        stations = res.json().get('results', [])
                        if not stations: break 
                        for sta in stations:
                            if "carrier" in sta.get('type', '').lower() or not sta.get('market_updated_at'): continue
                            try:
                                if (datetime.now(timezone.utc) - datetime.fromisoformat(sta['market_updated_at'].replace('Z', '+00:00'))).total_seconds() / 3600.0 > 48: continue
                            except: continue
                            for item in (sta.get('market') or []):
                                if item.get('commodity') == marchandise and item.get('supply', 0) >= 5000:
                                    achats_temporaires.append(formater_donnees(sta, marchandise, "ACHAT", item.get('buy_price', 0), item.get('supply', 0), moyennes_gal.get(marchandise, 0)))
                                    break
                    except: break 
            cibles_finales.extend(sorted(achats_temporaires, key=lambda x: x['prix_unitaire'])[:15])
        finaliser_scan(cibles_finales)
    except:
        mettre_a_jour_interface("Erreur Scan Achat", "red")
        scan_en_cours = False

def processus_scan_ventes():
    global scan_en_cours, systeme_actuel
    scan_en_cours = True
    mettre_a_jour_interface("Amorçage des senseurs...", "orange")
    try:
        parametres = obtenir_parametres()
        
        # 1. On interroge les DEUX soutes
        res_fc = requests.get(f"{SUPABASE_URL}/rest/v1/inventaire_fc?quantite=gt.0", headers=get_headers())
        res_ship = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.SHIP_CARGO", headers=get_headers())
        
        items_fc = res_fc.json() if res_fc.status_code == 200 else []
        items_ship = res_ship.json() if res_ship.status_code == 200 else []
        
        # 2. On fusionne et on additionne les quantités (si une marchandise est dans les deux)
        stocks_consolides = {}
        for item in items_fc:
            nom = item.get('marchandise')
            if nom: stocks_consolides[nom] = stocks_consolides.get(nom, 0) + item.get('quantite', 0)
            
        for item in items_ship:
            nom = item.get('target_commodity')
            if nom: stocks_consolides[nom] = stocks_consolides.get(nom, 0) + item.get('volume_disponible', 0)
            
        # 3. On trie le tout par quantité (du plus grand au plus petit) et on prend le Top 4
        marchandises_triees = sorted(stocks_consolides.items(), key=lambda x: x[1], reverse=True)
        marchandises_en_soute = [m[0] for m in marchandises_triees][:4]

        if not marchandises_en_soute:
            mettre_a_jour_interface("Soute vide. Scan annulé.", "red"); time.sleep(3); mettre_a_jour_interface(f">_ POSITION ACTUELLE : {systeme_actuel.upper()}", "#00F0FF"); scan_en_cours = False; return
            
        requests.delete(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.VENTE", headers=get_headers())
        cibles_finales = []
        for i, marchandise in enumerate(marchandises_en_soute):
            ventes_temporaires = []
            for (min_dist, max_dist) in [(0, 200), (200, 400), (400, 600), (600, 800), (800, 1000), (1000, 1200)]:
                mettre_a_jour_interface(f"Scan VENTE [{i+1}/{len(marchandises_en_soute)}] {marchandise} : {min_dist}-{max_dist} AL", "orange")
                for page in range(0, 10):
                    try:
                        res = requests.post("https://spansh.co.uk/api/stations/search", json={"filters": {"commodities": {"value": [marchandise]}, "distance": {"min": min_dist, "max": max_dist}, "has_market": {"value": True}, "is_fleet_carrier": {"value": False}, "has_large_pad": {"value": True}}, "reference_system": recuperer_dernier_systeme_connu(), "size": 250, "page": page}, timeout=10)
                        time.sleep(0.2) 
                        if res.status_code != 200: break 
                        stations = res.json().get('results', [])
                        if not stations: break 
                        for sta in stations:
                            if "carrier" in sta.get('type', '').lower() or not sta.get('market_updated_at'): continue
                            try:
                                if (datetime.now(timezone.utc) - datetime.fromisoformat(sta['market_updated_at'].replace('Z', '+00:00'))).total_seconds() / 3600.0 > 48: continue
                            except: continue
                            for item in (sta.get('market') or []):
                                if item.get('commodity') == marchandise and item.get('demand', 0) >= 5000:
                                    ventes_temporaires.append(formater_donnees(sta, marchandise, "VENTE", item.get('sell_price', 0), item.get('demand', 0), parametres.get('moyennes_galactiques', {}).get(marchandise, 0)))
                                    break
                    except: break 
            cibles_finales.extend(sorted(ventes_temporaires, key=lambda x: x['prix_unitaire'], reverse=True)[:5])
        finaliser_scan(cibles_finales)
    except:
        mettre_a_jour_interface("Erreur Scan Vente", "red")
        scan_en_cours = False

def processus_scan_predictif():
    global scan_en_cours, systeme_actuel
    scan_en_cours = True
    mettre_a_jour_interface("Amorçage Radar Prédictif (BGS)...", "orange")
    try:
        requests.delete(f"{SUPABASE_URL}/rest/v1/radar_commercial?type_operation=eq.PREDICTIF", headers=get_headers())
        cibles_finales = []
        for (min_dist, max_dist) in [(0, 500), (500, 1000), (1000, 1500), (1500, 2000)]:
            mettre_a_jour_interface(f"Scan PRÉDICTIF : {min_dist}-{max_dist} AL", "orange")
            for page in range(0, 10):
                try:
                    res = requests.post("https://spansh.co.uk/api/stations/search", json={"filters": {"primary_economy": {"value": ["Extraction", "Refinery", "Agriculture", "High Tech"]}, "distance": {"min": min_dist, "max": max_dist}, "has_large_pad": {"value": True}, "is_fleet_carrier": {"value": False}}, "reference_system": recuperer_dernier_systeme_connu(), "size": 250, "page": page}, timeout=10)
                    time.sleep(0.3) 
                    if res.status_code != 200: break 
                    stations = res.json().get('results', [])
                    if not stations: break 
                    for sta in stations:
                        if "carrier" in sta.get('type', '').lower(): continue
                        etat_faction = sta.get('controlling_minor_faction_state', '').lower()
                        if etat_faction not in ['infrastructure failure', 'bust', 'blight', 'outbreak', 'boom', 'investment']: continue
                        date_maj = sta.get('updated_at') or sta.get('market_updated_at')
                        if not date_maj: continue
                        try:
                            if (datetime.now(timezone.utc) - datetime.fromisoformat(date_maj.replace('Z', '+00:00'))).total_seconds() / 3600.0 > 48: continue
                        except: continue
                        cibles_finales.append(formater_donnees(sta, "MÉTAUX/MINÉRAUX", "PREDICTIF", 0, 0, 0))
                except: break 
        finaliser_scan(sorted(cibles_finales, key=lambda x: x['distance'])[:15])
    except:
        mettre_a_jour_interface("Erreur Scan Prédictif", "red")
        scan_en_cours = False

def formater_donnees(sta, marchandise, mode, prix, volume, prix_moyen):
    pad = 'L' if sta.get('has_large_pad') else '?'
    etat = sta.get('controlling_minor_faction_state', 'None').lower()
    etats = {"infrastructure failure": "INFRA. DÉFAILLANTE", "boom": "BOOM ÉCO.", "bust": "CRISE", "outbreak": "ÉPIDÉMIE", "investment": "INVESTISSEMENT", "blight": "FLÉAU"}
    tag = f" [{etats.get(etat, etat.upper())}]" if etat in etats else ""
    return {
        "system_name": sta.get('system_name'), 
        "station_name": f"{sta.get('name')} [PAD {pad}]{tag}", 
        "type_operation": mode, 
        "target_commodity": marchandise, 
        "prix_unitaire": prix, 
        "volume_disponible": volume, 
        "date_maj": sta.get('market_updated_at', 'Inconnue'), 
        "distance": sta.get('distance', 0), 
        "prix_moyen": prix_moyen, 
        "x": sta.get('x', 0), # <-- ON CAPTURE LES VRAIES COORDONNÉES X
        "y": sta.get('y', 0), # <-- ON CAPTURE LES VRAIES COORDONNÉES Y
        "z": sta.get('z', 0)  # <-- ON CAPTURE LES VRAIES COORDONNÉES Z
    }

def finaliser_scan(cibles_finales):
    global scan_en_cours
    if not cibles_finales: mettre_a_jour_interface("Scan terminé : 0 station trouvée.", "orange")
    else:
        mettre_a_jour_interface("Récupération EDSM & Transmission BDD...", "orange")
        for data in cibles_finales:
            try: requests.post(f"{SUPABASE_URL}/rest/v1/radar_commercial", headers=get_headers(), json=data)
            except: pass
        mettre_a_jour_interface("Liaison BDD terminée.", "#00FF00")
    time.sleep(3)
    mettre_a_jour_interface(f">_ POSITION ACTUELLE : {recuperer_dernier_systeme_connu().upper()}", "#00F0FF")
    scan_en_cours = False

def recalcul_distances_mathematiques(pos_vaisseau):
    try:
        vx, vy, vz = pos_vaisseau[0], pos_vaisseau[1], pos_vaisseau[2]
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?select=id,x,y,z&type_operation=in.(ACHAT,VENTE)", headers=get_headers())
        if res.status_code == 200:
            for cible in res.json():
                cx, cy, cz = cible.get('x', 0), cible.get('y', 0), cible.get('z', 0)
                if cx == 0 and cy == 0 and cz == 0: continue 
                requests.patch(f"{SUPABASE_URL}/rest/v1/radar_commercial?id=eq.{cible['id']}", headers=get_headers(), json={"distance": math.sqrt((cx - vx)**2 + (cy - vy)**2 + (cz - vz)**2)})
            mettre_a_jour_interface(f"Distances recalibrées", "#00FF00")
            time.sleep(2)
            mettre_a_jour_interface(f">_ POSITION ACTUELLE : {systeme_actuel.upper()}", "gray")
    except: pass

def enregistrer_transaction(system, station, entry, type_op):
    try:
        marchandise = formater_nom_marchandise(entry.get('Type', ''))
        qte = int(entry.get('Count', 0))
        prix_u = int(entry.get('BuyPrice', 0)) if type_op == 'ACHAT' else int(entry.get('SellPrice', 0))
        total = int(entry.get('TotalCost', 0)) if type_op == 'ACHAT' else int(entry.get('TotalSale', 0))
        
        # Récupération de l'ID via le canal radar (la seule table sans bouclier accessible à EDMC)
        user_id = None
        res = requests.get(f"{SUPABASE_URL}/rest/v1/radar_commercial?target_commodity=eq.APP_PARAMS", headers=get_headers())
        if res.status_code == 200 and len(res.json()) > 0:
            user_id = res.json()[0].get('user_id')
            
        if not user_id: 
            mettre_a_jour_interface(">_ ERREUR : OUVREZ L'INTERFACE WEB", "red")
            return
        
        payload = {
            "user_id": user_id,
            "type_operation": type_op,
            "systeme": system if system else "INCONNU",
            "station": station if station else "INCONNUE",
            "marchandise": marchandise,
            "quantite": qte,
            "prix_unitaire": prix_u,
            "total": total
        }
        
        # Transmission
        r = requests.post(f"{SUPABASE_URL}/rest/v1/journal_transactions", headers=get_headers(), json=payload)
        
        if r.status_code in [200, 201, 204]:
            mettre_a_jour_interface(f">_ REGISTRE : {type_op} {qte}T SAUVEGARDÉ", "#00FF66")
            
    except Exception as e:
        print(f"[SYS.EDTEAM] ERREUR JOURNAL : {e}")